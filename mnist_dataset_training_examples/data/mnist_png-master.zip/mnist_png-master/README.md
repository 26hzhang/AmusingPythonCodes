# mnist_png

Simple script to convert MNIST to PNG format.

PNG files are in `mnist_png.tar.gz`. Directory structure is:

    <training/testing> / <label> / <id>.png
